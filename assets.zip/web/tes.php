<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
 <video width="520" height="440" controls autoplay>
     <source src="video/stttelkom-1.webm" type="video/webm">
        <source src="video/stttelkom-1.mp4" type="video/mp4">
          <source src="video/stttelkom-1.ogg" type="video/ogg">
        Your browser does not support the video tag.
    </video> 
</body>
</html>