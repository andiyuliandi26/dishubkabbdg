<?php

return [
    'class' => 'yii\db\Connection',
	'dsn' => 'mysql:host=localhost;dbname=dishubka_cctv',
	'username' => 'dishubka_cctv',
	'password' => 'dishubkabbdg2017',
	'charset' => 'utf8',
];
